<?php

include 'redirect_to.php';

// Include the db_connect.php file to connect to the database
require_once 'db_connect.php';

// Define an array of table names and corresponding variables
$tables = [
    'product' => 'totalProducts',
    'category' => 'totalCategories',
    'customer' => 'totalCustomers',
    'orders' => 'totalOrders'
];

// Fetch data for each table and assign the values to variables
foreach ($tables as $table => $variable) {
    $query = "SELECT COUNT(*) AS total FROM $table";
    $stmt = $conn->prepare($query);
    $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    $$variable = $result['total'];
}

// Close the database connection
$conn = null;



?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/common-style.css">
    <link rel="stylesheet" href="css/data-style.css">
    <style>
      .analytics-card h3 {
    color:rgb(7, 7, 7); /* ตัวอักษรเป็นสีขาว */
    font-size: 23px; /* ขยายขนาดตัวอักษร */
    font-weight: bold; /* ทำให้ตัวอักษรหนาขึ้น */
    margin-top: 10px;
}
    .analytics-card i.fas.fa-box-open {
        color: #3498db; /* เปลี่ยนสีของไอคอนกล่อง */
    }

    .analytics-card i.fas.fa-tags {
        color:rgb(68, 204, 75); /* เปลี่ยนสีของไอคอนแท็ก */
    }

    .analytics-card i.fas.fa-user-friends {
        color:rgb(224, 228, 10); /* เปลี่ยนสีของไอคอนคน */
    }

    .analytics-card i.fas.fa-shopping-cart {
        color:rgb(240, 59, 14); /* เปลี่ยนสีของไอคอนตะกร้า */
    }
    /* ตั้งค่าพื้นฐานให้ลิงก์ไม่มีเส้นใต้ */
a {
  text-decoration: none;
  color: inherit;  /* สีเหมือนเดิม */
}

/* ทำให้ลิงก์มีการเปลี่ยนแปลงเมื่อ hover */
.analytics-card a:hover {
  opacity: 0.8;   /* เพิ่มเอฟเฟกต์ความโปร่งใส */
  transform: scale(1.05); /* ขยายขนาดเล็กน้อยเมื่อ hover */
  transition: all 0.3s ease; /* เพิ่มความนุ่มนวลในการเปลี่ยนแปลง */
}

/* ให้แต่ละช่องเป็นขนาดที่ใหญ่ขึ้น */
.analytics-card {
  background-color: #f4f4f4;  /* สีพื้นหลังของแต่ละช่อง */
  padding: 20px;              /* เว้นระยะขอบให้กับช่อง */
  border-radius: 10px;        /* ทำให้มุมของช่องกลม */
  text-align: center;         /* จัดข้อความให้อยู่กลาง */
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* เงาให้กับช่อง */
  transition: all 0.3s ease;  /* เอฟเฟกต์การเปลี่ยนแปลง */
}

/* สไตล์ของไอคอน */
.analytics-card i {
  font-size: 40px;
  color: #333;
  margin-bottom: 15px;
}

/* เพิ่มขนาดให้กับข้อความ */
.analytics-card h3 {
  font-size: 22px;
  margin-bottom: 10px;
  font-weight: 600;
}

.analytics-card span {
  font-size: 22px;
  font-weight: bold;
  color: #007bff;
}

/* ใช้ Flexbox เพื่อจัดเรียงช่องในแนวนอน 2 คอลัมน์ */
.analytics-cards {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  gap: 20px; /* เว้นระยะระหว่างช่อง */
}

/* ปรับขนาดให้ช่องใหญ่ขึ้นในแต่ละคอลัมน์ */
.analytics-card {
  width: calc(50% - 10px); /* ขนาดช่อง 50% ของความกว้างทั้งหมด */
  box-sizing: border-box; /* ให้ช่องไม่เกินขอบเขต */
}

/* ปรับขนาดสำหรับหน้าจอที่เล็กลง เช่นบนมือถือ */
@media (max-width: 768px) {
  .analytics-card {
    width: 100%; /* เมื่อหน้าจอเล็กลง จะให้แต่ละช่องเต็มความกว้าง */
  }
}

/* สไตล์ของตาราง */
.table-container {
  margin: 20px 0;
  padding: 20px;
  background-color: #f4f4f4;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.dashboard-table {
  width: 100%;
  border-collapse: collapse;
}

.dashboard-table th, .dashboard-table td {
  padding: 12px;
  text-align: center;
  border: 1px solid #ddd;
}

.dashboard-table th {
  background-color: #2c3e50;
  color: #fff;
  font-size: 16px;
}

.dashboard-table td {
  background-color: #fff;
  color: #333;
}

.dashboard-table tr:hover {
  background-color: #f1f1f1;
}

.view-btn {
  padding: 8px 16px;
  background-color: #3498db;
  color: white;
  text-decoration: none;
  border-radius: 5px;
  font-size: 14px;
}

.view-btn:hover {
  background-color: #2980b9;
}

/* สไตล์ของกราฟ */
.chart-container {
  width: 80%;
  margin: 20px auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* สไตล์ของ footer */
footer {
  background-color: #2c3e50;
  color: #bdc3c7;
  padding: 20px 0;
  text-align: center;
  font-family: Arial, sans-serif;
}

footer p {
  margin: 0;
  font-size: 13px;
}
</style>
</head>

<body>

<?php include 'common-section.php'; ?>

<h2>Dashboard</h2>

<div class="analytics-section">
  <div class="analytics-cards">
    <div class="analytics-card">
      <a href="dash-prod.php">
        <i class="fas fa-box-open"></i>
        <h3>Total Products</h3>
        <span><?php echo $totalProducts; ?></span>
      </a>
    </div>
    <div class="analytics-card">
      <a href="dash-catg.php">
        <i class="fas fa-tags"></i>
        <h3>Total Categories</h3>
        <span><?php echo $totalCategories; ?></span>
      </a>
    </div>
    <div class="analytics-card">
      <a href="dash-cust.php">
        <i class="fas fa-user-friends"></i>
        <h3>Total Customers</h3>
        <span><?php echo $totalCustomers; ?></span>
      </a>
    </div>
    <div class="analytics-card">
      <a href="dash-order.php">
        <i class="fas fa-shopping-cart"></i>
        <h3>Total Orders</h3>
        <span><?php echo $totalOrders; ?></span>
      </a>
    </div>
  </div>
</div>
<div class="table-container">
    <table class="dashboard-table">
        <thead>
            <tr>
                <th>Category</th>
                <th>Total</th>
                <th>Details</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Total Products</td>
                <td><?php echo $totalProducts; ?></td>
                <td><a href="dash-prod.php" class="view-btn">View</a></td>
            </tr>
            <tr>
                <td>Total Categories</td>
                <td><?php echo $totalCategories; ?></td>
                <td><a href="dash-catg.php" class="view-btn">View</a></td>
            </tr>
            <tr>
                <td>Total Customers</td>
                <td><?php echo $totalCustomers; ?></td>
                <td><a href="dash-cust.php" class="view-btn">View</a></td>
            </tr>
            <tr>
                <td>Total Orders</td>
                <td><?php echo $totalOrders; ?></td>
                <td><a href="dash-order.php" class="view-btn">View</a></td>
            </tr>
        </tbody>
    </table>
</div>

<!-- กราฟ -->
<div class="chart-container">
    <canvas id="dashboardChart"></canvas>
</div>

<!-- Footer Section -->
<footer>
    <div class="footer-content">
        <p>&copy; <?php echo date("Y"); ?> JWR Inventory Management System. All Rights Reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // ข้อมูลที่จะแสดงในกราฟ
    const data = {
        labels: ['Total Products', 'Total Categories', 'Total Customers', 'Total Orders'],
        datasets: [{
            label: 'Total Counts',
            data: [
                <?php echo $totalProducts; ?>, 
                <?php echo $totalCategories; ?>, 
                <?php echo $totalCustomers; ?>, 
                <?php echo $totalOrders; ?>
            ],
            backgroundColor: [
                'rgba(23, 152, 238, 0.2)', // สีน้ำเงินอ่อนสำหรับ Total Products
                'rgba(20, 240, 86, 0.2)', // ส้มสำหรับ Total Categories
                'rgba(243, 239, 18, 0.2)', // สีเขียวสำหรับ Total Customers
                'rgba(236, 15, 15, 0.2)' // สีม่วงสำหรับ Total Orders
            ],
            borderColor: [
                'rgba(54, 162, 235, 1)', 
                'rgb(19, 241, 56)', 
                'rgb(222, 245, 14)', 
                'rgb(247, 16, 16)'
            ],
            borderWidth: 1
        }]
    };

    // ตัวเลือกการตั้งค่ากราฟ
    const config = {
        type: 'bar', // กำหนดเป็นกราฟแท่ง
        data: data,
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    };

    // สร้างกราฟ
    const dashboardChart = new Chart(
        document.getElementById('dashboardChart'),
        config
    );
</script>

<!-- Optional CSS Styling -->
<style>
    footer {
        background-color:rgb(255, 251, 251);  /* สีพื้นหลัง */
        color: #fff;
        text-align: center;
        padding: 5px 0;
        position: fixed;
        width: 100%;
        bottom: 0;
    }

    .footer-content p {
        margin: 0;
        font-size: 14px;
    }

    .footer-content a {
        color: #fff;
        text-decoration: none;
    }

    .footer-content a:hover {
        text-decoration: underline;
    }
</style>
</html>
